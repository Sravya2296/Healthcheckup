package com.cts.healthCheckup;

import java.io.File;
import java.io.IOException;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class HealthCheckUp {
	
	static String url;
	static String Tomcat_Status=null;
	static String application_Reachability=null;
	
	 private URLConnection conn;
	 private List<String> cookies;
	 File[] attachment=new File[2]; 

	public static void main(String[] args) throws IOException, InterruptedException {
		
		  Logger log = Logger.getLogger(HealthCheckUp.class.getName());
		   
		HealthCheckUp healthcheckup=new HealthCheckUp();
		JVM_Memory jvm=new JVM_Memory();
		String URL=getProperty.getProperty("Tomcat_homePage");
		SimpleDateFormat sdf=new SimpleDateFormat("YYYYMMdd");
		Date date=new Date();
		String CurrentDate=sdf.format(date);
		String SnippetPath1=getProperty.getProperty("Snippet_Path1");
		log.debug("Sniipet path"+SnippetPath1);
		log.info(SnippetPath1);
		
		String SnippetPath2=getProperty.getProperty("Snippet_Path2");
		log.debug("Sniipet path2"+SnippetPath2);
		log.info(SnippetPath2);
		
		System.out.println("Snippet path1"+SnippetPath1);
		System.out.println("Snippet path2"+SnippetPath2);
		ServerStatus.ServerStatus(URL,"TomcatHomePage_"+CurrentDate,SnippetPath1);
				
		String Application_Reachablity_URL=getProperty.getProperty("Application_Reachablity");
		System.out.println(Application_Reachablity_URL);
		log.debug("Application reachablity URL"+Application_Reachablity_URL);
		log.info(Application_Reachablity_URL);
		
		ServerStatus.ServerStatus(Application_Reachablity_URL, "Application_Reachable"+CurrentDate,SnippetPath2);
	    String JVM_URL=getProperty.getProperty("Tomcat_Status");
	    log.debug("JVM URL"+JVM_URL);
		log.info(JVM_URL);
		String name = getProperty.getProperty("Tomcat_Username");
		String password = getProperty.getProperty("Tomcat_Password");
		String JVM_mem=jvm.JVM_Memory(JVM_URL,name,password);
		log.debug("JVM memory"+JVM_mem);
		log.info(JVM_mem);
		String logFile=getProperty.getProperty("Log_Filepath");
		log.debug("log file path"+logFile);
		log.info(logFile);
		System.out.println("*****"+logFile);
		File lastmp=getLatestFilefromDir.getLatestFilefromDir(logFile);
		log.debug("latset log file"+lastmp);
		log.info(lastmp);
	    List list=readLastLine.readLastLine(lastmp, 10);
	    list.forEach(x -> System.out.println(x));
	   log.debug("log file"+list);
		log.info(list);
	 
	   File attachmnets= ReadAttachmnet.ReadAttachmnet(SnippetPath1,SnippetPath2);
	   System.out.println("******");
	   
	   SendMail.SendMail(JVM_mem,list,attachmnets);
	   
	   log.debug("mail sent succesfully");
		

	}

}
