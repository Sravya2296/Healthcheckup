package com.cts.healthCheckup;

import java.io.File;

import org.apache.log4j.Logger;

public class ReadAttachmnet {
	static File ReadAttachmnet(String atachmentPath,String attachmnetPath2) {
		// TODO Auto-generated method stub
		Logger log = Logger.getLogger(HealthCheckUp.class.getName());
		//File file=getLatestFilefromDir(atachmentPath);
		//System.out.println(file);
		File[] attachemnets1=new File[2];
		
		File dir = new File(atachmentPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }

	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           attachemnets1[0] = files[i];
	          
	           
	       }
	    }
	    System.out.println("attachement 1@@@"+attachemnets1[0]);
	    log.debug(attachemnets1[0]);
		File dir1 = new File(attachmnetPath2);
	    File[] files1 = dir1.listFiles();
	    if (files1 == null || files1.length == 0) {
	        return null;
	    }

	    File lastModifiedFile1 = files1[0];
	    for (int i = 1; i < files1.length; i++) {
	       if (lastModifiedFile.lastModified() < files1[i].lastModified()) {
	           attachemnets1[1] = files1[i];
	           
	       }
	    }
	    System.out.println("attachamnet2"+attachemnets1[1]);
	    return attachemnets1[1];
		
		
	//	attachemnets[0]=file;
		//file.delete();

}
	

}
