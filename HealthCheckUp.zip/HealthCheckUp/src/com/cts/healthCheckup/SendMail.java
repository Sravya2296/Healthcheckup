package com.cts.healthCheckup;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.crypto.spec.SecretKeySpec;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

public class SendMail {
	
	static void SendMail(String JVM_mem,List log,File attachmnets) throws IOException {
		// TODO Auto-generated method stub
		FileReader fileReader;
		try {
			Logger log1 = Logger.getLogger(HealthCheckUp.class.getName());
		//	fileReader = new FileReader("C:\\Snippet\\PropertyFie\\HealtChecup.properties");
//
	//	Properties properties = new Properties();
		//	properties.load(fileReader);
		String reportsDir = getProperty.getProperty("Snippet_Path");


			final String username = getProperty.getProperty("EMAIL_ID");//"780544@cognizant.com";//emailid
			final String password = getProperty.getProperty("PASSWORD"); //"wDzeYvIc3x5d8BdRvF5K5Q==:LTn/qJUG2GMeHXiRf3kW6w==";//password
			String subject = getProperty.getProperty("Mail_Subject");
			/* mySession.getTraceOutput().writeln(ITraceInfo.TRACE_LEVEL_INFO, CLASS_NAME +" EMAIL_ID from property file:: "+username);
		        mySession.getTraceOutput().writeln(ITraceInfo.TRACE_LEVEL_INFO, CLASS_NAME +" PASSWORD from property file:: "+password);
			 */
			System.err.println("email");
			byte[] salt = new String("12345678").getBytes();
			int iterationCount = 40000;
			int keyLength = 128;
			SecretKeySpec key = ProtectedConfigFile.createSecretKey(username.toCharArray(), salt, iterationCount, keyLength);
			System.out.println(key);
			//final String decryptedPassword = ProtectedConfigFile.decrypt(password, key);
			final String decryptedPassword="em0arZt0qwU/O4iXQgcbGg==:DixNmSAf0fC7Sj8sYSOUEA==";
			System.out.println( " decryptedPassword:: "+password);
            log1.debug(" decryptedPassword:: "+password);
            log1.info(" decryptedPassword:: "+password);
			Properties prop = new Properties();

			prop.put("mail.smtp.host", "APACSMTP.CTS.COM");
			prop.put("mail.smtp.port", "25");
			prop.put("mail.smtp.auth", "true");
			prop.put("mail.smtp.starttls.enable", "true"); 

			Session session = Session.getInstance(prop,
					new javax.mail.Authenticator() {
				protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
					return new javax.mail.PasswordAuthentication(username, decryptedPassword);
				}
			});
			System.out.println(" Sending Email.. ");
			log1.debug("Sending mail.......");
			Message message = new MimeMessage(session);
			//message.setFrom(new InternetAddress("IVRNotification@cognizant.com"));
			//InternetAddress sendTo = new InternetAddress(properties.getProperty("SEND_TO"));			
			message.setRecipients(Message.RecipientType.TO,   InternetAddress.parse(getProperty.getProperty("SEND_TO"),true));
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(getProperty.getProperty("SEND_CC"),true));
			message.setSubject(subject);

           System.out.println(message);
			BodyPart messageBodyPart = new MimeBodyPart();
			Multipart multipart = new MimeMultipart();
			// Now set the actual message
			//messageBodyPart.setText("Please find attched IVR health checkup report for Dunkins."+"\n\n\n"+"JVM memory"+"\n\n"+JVM_mem+"\n\n\n"+"Application Logs"+"\n"+log);
           String img=attachmnets.toString();
			String html="<H4>Please find the attached IVR healthcheckup report</H4>";
			html=html+"<head>\r\n" + 
					"<style>\r\n" + 
					"table, th, td {\r\n" + 
					"  border: 1px solid black;\r\n" + 
					"}\r\n" + 
					"</style>\r\n" + 
					"</head><table><tr><th>Activity</><th>Status(Prod Server)</th><tr><td>Availability of VM</td><td>"+ServerStatus.VM_Connectivity+"</td></tr><tr><td>Status of tomcat service</td><td>"+ServerStatus.Tomcat_Status+"</td></tr><tr>SMART IVR application logging</td><td>Loging</td></tr><tr><td>IVR application URL rechability</td><td>"+ServerStatus.application_Reachability+"</td></tr></table>";
			html=html+"<H1>JVM memory</H1>";
			html=html+JVM_mem;
			//html=html+"Application Reachability";
			html=html+"<img src=\"cid:image\" alt=\"Trulli\" width=\"1000\" height=\"333\">";
			html=html+"<H1>Application logs</H1>";
			html=html+log;
			// Create a multipart message
		    messageBodyPart.setContent(html, "text/html");
		    
			

			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			
			
			messageBodyPart = new MimeBodyPart();
	         DataSource fds = new FileDataSource(attachmnets);

	         messageBodyPart.setDataHandler(new DataHandler(fds));
	         messageBodyPart.setHeader("Content-ID", "<image>");

	         // add image to the multipart
	         multipart.addBodyPart(messageBodyPart);

	         // put everything together
	         message.setContent(multipart);
			
			
			// send message
			Transport.send(message);
			System.out.println(" Mail sent successsfully");
			log1.debug("mail sent successfully.......");

		} catch (NoSuchAlgorithmException e) {
			System.out.println(" NoSuchAlgorithmException :: "+e);
		} catch (InvalidKeySpecException e) {
			System.out.println(" InvalidKeySpecException :: "+e);
		} catch (MessagingException e) {
			System.out.println(" MessagingException :: "+e);
		} catch (Exception e) {
			System.out.println(" Exception :: "+e);
		}
        }

}
