package com.cts.healthCheckup;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

public class ServerStatus extends Thread {
	static String url;
	static String Tomcat_Status="Not_Running";
	static String application_Reachability=null;
	static String VM_Connectivity=null;
	
	private URLConnection conn;
	 private List<String> cookies;
	 File[] attachment=new File[2];	
	static String ServerStatus(String URL, String Name_SS,String SnippetPath) throws InterruptedException {
		// TODO Auto-generated method stub
		try {			
			java.net.URL url = new URL(URL);
          	HttpURLConnection connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod("GET");
			
			 
			connection.connect();
	      
			
			int code = connection.getResponseCode();
			System.out.println("Response code"+code);
			
			if(!(code==200))
			{
				System.out.println("tomcat is not running");
				application_Reachability="Not_reaching";
				VM_Connectivity="Connecting";
				openURL.openURL(URL);
				sleep(500);
				snippet.snippet(Name_SS,SnippetPath);
			}
			else
			{
				System.out.println("Tomcat is running");
				Tomcat_Status="Running";
				application_Reachability="reaching";
				VM_Connectivity="Connecting";
				openURL.openURL(URL);
				sleep(500);
				snippet.snippet(Name_SS,SnippetPath);
			}
		}
		
		catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		;
		return Name_SS;
	}
}
