package com.cts.healthCheckup;

import java.io.File;

import org.apache.log4j.Logger;

public class getLatestFilefromDir {
	
	
	static File getLatestFilefromDir(String path) {
		Logger log = Logger.getLogger(HealthCheckUp.class.getName());
		File dir = new File(path);
	    File[] files = dir.listFiles();
	    System.out.println("list of files"+files.length);
	    if (files == null || files.length == 0) {
	        return null;
	    }

	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	           System.out.println(lastModifiedFile);
	           System.out.println(lastModifiedFile.lastModified());
	           log.debug(lastModifiedFile);
	           log.info(lastModifiedFile);
	           
	           long las=lastModifiedFile.lastModified();
          
	      
	       }
	    }
	    return lastModifiedFile;
	}
}
