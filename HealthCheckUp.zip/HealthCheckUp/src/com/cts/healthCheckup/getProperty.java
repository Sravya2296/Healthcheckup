package com.cts.healthCheckup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class getProperty {
	static String url;
	public static String getProperty(String keyword)
	{
		Logger log = Logger.getLogger(HealthCheckUp.class.getName());
		
		try {
			File file=new File("C:\\Snippet\\PropertyFie\\HealthCheckup.properties");
			FileInputStream fin=new FileInputStream(file);
			Properties prop=new Properties();
			prop.load(fin);
			 url=prop.getProperty(keyword);
			 log.debug("Property file path"+file);
			 log.info(file);
			 log.debug("URL"+"URL:"+keyword+":"+url);
			 log.info("URL:"+keyword+":"+url);
			 System.out.println("Property file path ...."+file);
			 System.out.println("URL:"+keyword+":"+url);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return url;
		
	}

}
