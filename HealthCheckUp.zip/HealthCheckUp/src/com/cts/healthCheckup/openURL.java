package com.cts.healthCheckup;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.log4j.Logger;

public class openURL {
	static String url;
	
	static void openURL(String url) {
		Logger log = Logger.getLogger(HealthCheckUp.class.getName());
		 if(Desktop.isDesktopSupported()){
		        Desktop desktop = Desktop.getDesktop();
		        try {
		        	
		        	System.out.println("Inside open url .....");
		        	log.debug("Inside open url .....");
		        	log.info("Inside open url .....");
		        	desktop.browse(new URI(url));
		         
		        } catch (IOException | URISyntaxException e) {
		            // TODO Auto-generated catch block
		        	System.out.println("error"+e.getMessage());
		            e.printStackTrace();
		        }
		    }else{
		        Runtime runtime = Runtime.getRuntime();
		        try {
		            runtime.exec("xdg-open " + url);
		        } catch (IOException e) {
		            // TODO Auto-generated catch block
		        	System.out.println("error"+e.getMessage());
		            e.printStackTrace();
		        }
		    }

	}
}
