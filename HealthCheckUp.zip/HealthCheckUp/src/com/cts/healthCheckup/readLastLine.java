package com.cts.healthCheckup;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.input.ReversedLinesFileReader;

public class readLastLine {
	static List readLastLine(File lastmp, int i) {
		List<String> result = new ArrayList<>();
	     
	    try (ReversedLinesFileReader reader = new ReversedLinesFileReader(lastmp, i, StandardCharsets.UTF_8)) {

	        String line = "";
	        while ((line = reader.readLine()) != null && result.size() < i) {
	            result.add(line);
	           
	        }
	       
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    return result;

	}
}
