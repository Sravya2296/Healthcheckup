package com.cts.healthCheckup;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class snippet {
	public static void snippet(String s, String snippetPath)
	{


	 try { 
	     Thread.sleep(1200); 
	     Robot r = new Robot(); 

	          
	     String path = snippetPath+s+".jpg"; 

	     // Used to get ScreenSize and capture image 
	     Rectangle capture =  
	     new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()); 
	     BufferedImage Image = r.createScreenCapture(capture); 
	     ImageIO.write(Image, "jpg", new File(path)); 
	     System.out.println("Screenshot saved"); 
	 } 
	 catch (AWTException | IOException | InterruptedException ex) { 
	     System.out.println(ex); 
	 } 
	}

}
